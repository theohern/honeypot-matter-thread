dir="/usr/share/grafana/csv"

touch $dir/count_changes.csv
chmod 777 $dir/count_changes.csv

touch $dir/ha_all_logs.csv
chmod 777 $dir/ha_all_logs.csv

touch $dir/ha_log_entries.csv
chmod 777 $dir/ha_log_entries.csv

touch $dir/matter-stat.csv
chmod 777 $dir/matter-stat.csv

touch $dir/homeassistant-stat.csv
chmod 777 $dir/homeassistant-stat.csv

touch $dir/matterLogs.csv
chmod 777 $dir/matterLogs.csv

touch $dir/node.csv
chmod 777 $dir/node.csv

touch $dir/subscription.csv
chmod 777 $dir/subscription.csv

touch $dir/entity_log_entries.csv
chmod 777 $dir/entity_log_entries.csv

touch $dir/thread_logs.csv
chmod 777 $dir/thread_logs.csv

touch $dir/thread_nodes.csv
chmod 777 $dir/thread_nodes.csv

touch $dir/connection_attempts.csv
chmod 777 $dir/connection_attempts.csv

cd $dir
mkdir parsing 
mkdir matter
